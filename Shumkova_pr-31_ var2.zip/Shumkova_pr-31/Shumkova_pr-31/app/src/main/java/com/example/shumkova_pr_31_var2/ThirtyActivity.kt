package com.example.shumkova_pr_31_var2

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.TextView

class ThirtyActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_thirty)
        val number: TextView = findViewById(R.id.t)
        val nValue = intent.getDoubleExtra( "number", 0.0)
        number.text = "Введенное число - $nValue"

        val result: TextView = findViewById(R.id.t2)
        val rValue = intent.getDoubleExtra("result", 0.0)
        result.text = "Результат - $rValue"

    }

    fun back(view: View) {
        val intent = Intent(this,MainActivity::class.java)
        startActivity(intent)
    }
}