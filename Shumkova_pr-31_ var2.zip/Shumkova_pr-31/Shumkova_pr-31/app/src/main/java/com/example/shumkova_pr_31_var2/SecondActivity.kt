package com.example.shumkova_pr_31_var2

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast

class SecondActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second)
        val units = arrayOf("Байт", "Килобайт", "Мегабайт", "Гигабайт")
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, units)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)

        val spinner1 = findViewById<View>(R.id.t3) as Spinner
        spinner1.adapter = adapter
        spinner1.setSelection(1)
        val spinner2 = findViewById<View>(R.id.t4) as Spinner
        spinner2.adapter = adapter
        spinner2.setSelection(0)

        val buttonStart: Button = findViewById(R.id.button2)
        val chislo: EditText = findViewById(R.id.t)
        val rez: TextView = findViewById(R.id.t2)

        buttonStart.setOnClickListener {
            if (chislo.text.isNotEmpty()) {
                val inputValue = chislo.text.toString().toDouble()
                val inputUnit = spinner1.selectedItemPosition
                val outputUnit = spinner2.selectedItemPosition

                val outputValue = convert(inputValue, inputUnit, outputUnit)
                rez.text = "$outputValue ${units[outputUnit]}"

                val intent = Intent(this, ThirtyActivity::class.java)
                intent.putExtra("number", inputValue)
                intent.putExtra("result", outputValue)
                startActivity(intent)
            } else {
                Toast.makeText(this, "Введи число", Toast.LENGTH_SHORT).show()
                rez.text = "Результат"
            }
        }
    }
    private fun convert(value: Double, inputUnit: Int, outputUnit: Int): Double {
        val baseUnits = arrayOf(1, 1024, 1024 * 1024, 1024 * 1024 * 1024)
        val inputValueInBytes = value * baseUnits[inputUnit]
        val outputValue = inputValueInBytes / baseUnits[outputUnit]
        return outputValue
    }
}