package com.example.shumkova_pr_31_var2

import android.content.Intent
import android.content.SharedPreferences
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v7.app.AlertDialog
import android.support.v7.widget.AppCompatButton
import android.view.View
import android.widget.EditText
import android.widget.Toast

lateinit var login:EditText
lateinit var  password: EditText
lateinit var button: AppCompatButton
lateinit var  getPass: SharedPreferences
class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        button = findViewById(R.id.button1)
        login = findViewById(R.id.login)
        password = findViewById(R.id.password)
        button.setOnClickListener(){
            if(login.text.isNotEmpty()&& password.text.isNotEmpty()){
                val sharedPreferences = getSharedPreferences("User", MODE_PRIVATE)
                val loginpref = sharedPreferences.getString("login","")
                val passwordpref = sharedPreferences.getString("password","")
                if(loginpref == login.text.toString() && passwordpref == password.text.toString()){
                    var intent = Intent(this, SecondActivity::class.java)
                    startActivity(intent)
                }else{
                    showAlert("Неверный логин или пароль")
                }
            }
            if (login.text.isEmpty() || password.text.isEmpty()){
                showAlert("Введите логин или пароль")
            }
        }
        val sharedPreferences = getSharedPreferences("User", MODE_PRIVATE)
        val ed: SharedPreferences.Editor = sharedPreferences.edit()
        ed.putString("login","ects")
        ed.putString("password","ects123")
        ed.apply()


    }
    private fun showAlert(message: String){
        AlertDialog.Builder(this).setMessage(message).setPositiveButton("okay"){
                dialog,_ -> dialog.dismiss()
        }
            .show()
    }

    }

